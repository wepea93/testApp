namespace ProductService.Core.Contracts;

public interface IProductCreated
{
    int ProductId { get; }
}