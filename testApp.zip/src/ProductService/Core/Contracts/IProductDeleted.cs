namespace ProductService.Core.Contracts;

public interface IProductDeleted
{
    int ProductId { get; }
}