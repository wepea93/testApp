namespace ProductService.Core.Contracts;

public interface IGetProductById
{
    int ProductId { get; }
}

