namespace InventoryService.Core.Contracts;

public interface IProductCreated
{
    int ProductId { get; }
}