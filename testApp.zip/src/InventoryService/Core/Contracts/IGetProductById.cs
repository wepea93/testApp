namespace InventoryService.Core.Contracts;

public interface IGetProductById
{
    int ProductId { get; }
}

